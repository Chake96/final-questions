package QuestionA;

import java.util.Date;
import java.util.UUID;

public interface iPersonRead {
	
	UUID getPersonID();
	
	String getFirstName();
	
	Date getDOB();
	
	String getLastName();
	
	String getMiddleName();
	
	String getAddress();
	
	String getPhone();
	
	String getEmail();
	
	
	
}
